package sabujak.hobby.control;

import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import file.model.FileSet;
import sabujak.domain.Hboard;
import sabujak.domain.Review;
import sabujak.hobby.model.HboardService;
import sabujak.hobby.vo.ListResult;
import sabujak.review.model.ReviewService;
import sabujak.review.vo.ListResultRev;

/**
 * Servlet implementation class HboardController
 */
@WebServlet("/hboard/board.do")
public class HboardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private String m ="";
    MultipartRequest mr = null;
    
	public void service(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		m = request.getParameter("m");
		if(m != null) {
			m=m.trim();
			if(m.equals("list")) {
				list(request,response);
			}else if(m.equals("write")){
				write(request,response);
			}else if(m.equals("insert")){
				insert(request,response);
			}else if(m.equals("content")){
				content(request,response);
			}else if(m.equals("del")){
				del(request,response);
			}else if(m.equals("update")){
				content(request,response);
			}else if(m.equals("updateOk")){
				updateOk(request,response);
			}else if(m.equals("rev_save")){
				rev_save(request,response);
			}else if(m.equals("rev_del")){
				content(request,response);
			}
		}else {
			list(request,response);
		}
	}
	private void list(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		String cpStr = request.getParameter("cp");
		String psStr = request.getParameter("ps");
		HttpSession session = request.getSession();
		int cp = 1;
		if(cpStr == null) {
			Object cpObj = session.getAttribute("cp");
			if(cpObj != null) {
				cp = (Integer)cpObj;
			}
		}else {
			cpStr = cpStr.trim();
			cp = Integer.parseInt(cpStr);
		}
		session.setAttribute("cp", cp);
		int ps = 3;
		if(psStr == null) {
			Object psObj = session.getAttribute("ps");
			if(psObj != null) {
				ps = (Integer)psObj;
			}
		}else {
			psStr = psStr.trim();
			int psParam = Integer.parseInt(psStr);
			
			Object psObj = session.getAttribute("ps");
			if(psObj != null) {
				int psSession = (Integer)psObj;
				if(psSession != psParam) {
					cp = 1;
					session.setAttribute("cp", cp);
				}
			}else {
				if(ps != psParam) {
					cp =1;
					session.setAttribute("cp", cp);
				}
			}
			ps = psParam;
		}
		session.setAttribute("ps", ps);
		
		HboardService service = HboardService.getInstance();
		ListResult listResult = service.getListResult(cp, ps);
		request.setAttribute("listResult", listResult);
		if(listResult.getList().size()==0) {
			if(cp>1) {
				response.sendRedirect("hboard.do?m=list&cp="+(cp-1));
			}else {
				request.setAttribute("listResult", null);
				String view = "list.jsp";
				RequestDispatcher rd = request.getRequestDispatcher(view);
				rd.forward(request,response);
			}
		}else {
			String view = "list.jsp";
			RequestDispatcher rd = request.getRequestDispatcher(view);
			rd.forward(request, response);
		}
	}
	private void write(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		String view ="write.jsp";
		response.sendRedirect(view);
	}
	private void insert(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		setMR(request,response);
		HboardService service = HboardService.getInstance();
		
		String hcode_fkStr = mr.getParameter("category");
		if(hcode_fkStr != null) hcode_fkStr = hcode_fkStr.trim();
		int hcode_fk =0;
		if(hcode_fkStr.length() != 0) {
			hcode_fk = Integer.parseInt(hcode_fkStr);
		}
		String email_fk = mr.getParameter("writer");
		String h_sub = mr.getParameter("title");
		String h_cont = mr.getParameter("content");
		service.insertS(new Hboard(-1,hcode_fk,h_sub,h_cont,0,null,0,email_fk));
		String view = "board.do";
		response.sendRedirect(view);

	}
	private void content(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		HboardService service = HboardService.getInstance();
		String h_noStr = request.getParameter("h_no");
		if(h_noStr != null) h_noStr = h_noStr.trim();
		int h_no = 0;
		if(h_noStr.length()!=0) {
			h_no = Integer.parseInt(h_noStr);
		}
		String h_viewStr = request.getParameter("h_view");
		if(h_viewStr != null) h_viewStr = h_viewStr.trim();
		int h_view = 0;
		if(h_viewStr.length()!=0) {
			h_view = Integer.parseInt(h_viewStr);
		}
		Hboard hboard = service.contentS(h_no);
		service.viewUpS(h_no, h_view);
		request.setAttribute("hboard", hboard);
		ReviewService revService = ReviewService.getInstance();
		ArrayList<Review> listRev = revService.listRev(h_no);
		request.setAttribute("listRev", listRev);
		String view ="";
		if(m.equals("content")) {
			view = "content.jsp";
		}else if(m.equals("update")) {
			view  ="update.jsp";
		}else if(m.equals("rev_del")) {
			String rev_noStr = request.getParameter("rev_no");
			if(rev_noStr != null) rev_noStr = rev_noStr.trim();
			int rev_no = 0;
			if(rev_noStr.length()!=0) {
				rev_no = Integer.parseInt(rev_noStr);
			}
			revService.delRevS(rev_no);
			view ="board.do?m=content&h_no="+h_no;
		}
		RequestDispatcher rd = request.getRequestDispatcher(view);
		rd.forward(request, response);
	}
	private void del(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		String h_noStr = request.getParameter("h_no");
		if(h_noStr != null) h_noStr = h_noStr.trim();
		int h_no = 0;
		if(h_noStr.length()!=0) {
			h_no = Integer.parseInt(h_noStr);
		}
		HboardService service = HboardService.getInstance();
		service.delS(h_no);
		String view = "board.do";
		response.sendRedirect(view);
	}
	private void updateOk(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		HboardService service = HboardService.getInstance();
		setMR(request,response);
		String h_noStr = request.getParameter("h_no");
		if(h_noStr != null) h_noStr = h_noStr.trim();
		int h_no = 0;
		if(h_noStr.length()!=0) {
			h_no = Integer.parseInt(h_noStr);
		}
		String hcode_fkStr = mr.getParameter("category");
		if(hcode_fkStr != null) hcode_fkStr = hcode_fkStr.trim();
		int hcode_fk =0;
		if(hcode_fkStr.length() != 0) {
			hcode_fk = Integer.parseInt(hcode_fkStr);
		}
		String h_sub = mr.getParameter("title");
		String h_cont = mr.getParameter("content");
		
		service.updateS(new Hboard(h_no,hcode_fk,h_sub,h_cont,0,null,0,null));
		String view = "board.do";
		response.sendRedirect(view);
	}
	private void rev_save(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ReviewService revService = ReviewService.getInstance();
		
		String rev_goodStr = request.getParameter("rev_good");
		if(rev_goodStr != null) rev_goodStr = rev_goodStr.trim();
		int rev_good =0;
		if(rev_goodStr.length() != 0) {
			rev_good = Integer.parseInt(rev_goodStr);
		}
		String h_noStr = request.getParameter("h_no");
		if(h_noStr != null) h_noStr = h_noStr.trim();
		int h_no = 0;
		if(h_noStr.length()!=0) {
			h_no = Integer.parseInt(h_noStr);
		}
		String email_fk = request.getParameter("email_fk");
		String rev_cont = request.getParameter("rev_cont");
		revService.insertRevS(new Review(-1, h_no, rev_good, null, rev_cont, null, email_fk));
		String view = "board.do?m=content&h_no="+h_no;
		response.sendRedirect(view);
		
	}
	private void setMR(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		HboardService service = HboardService.getInstance();
		ServletContext application = getServletContext();
		
		String saveDirectory = FileSet.FILE_DIR;
		File fSaveDir = new File(saveDirectory);
		if(!fSaveDir.exists()) fSaveDir.mkdirs();
		
		int maxPostSize = 300*1024*1024;
		String encoding = "utf-8";
		DefaultFileRenamePolicy policy = new DefaultFileRenamePolicy();
		try {
			mr = new MultipartRequest(request, saveDirectory, maxPostSize,encoding,policy);
		}catch(IOException ie) {
		}
	}
}
